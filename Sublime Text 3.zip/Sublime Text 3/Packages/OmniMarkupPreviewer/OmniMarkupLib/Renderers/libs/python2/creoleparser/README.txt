About Creoleparser
==================

Creoleparser is a Python implementation of a parser for the Creole wiki markup language.

For more information please visit:

http://purl.oclc.org/creoleparser

